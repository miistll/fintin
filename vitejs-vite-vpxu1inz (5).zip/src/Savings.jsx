import React, { useState, useEffect } from "react";
import "./Savings.css";

function getDateKey(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

export default function Savings({
  onNavigate,
  saved,
  setSaved,
  goal,
  setGoal,
  goalName,
  setGoalName,
  history,
  setHistory,
}) {
  const [showCelebration, setShowCelebration] = useState(false);
  const [dismissedForGoal, setDismissedForGoal] = useState(null);

  const progress = goal > 0 ? Math.min(100, (saved / goal) * 100) : 0;
  const goalReached = goal > 0 && saved >= goal;

  useEffect(() => {
    if (goalReached && dismissedForGoal !== goal) {
      setShowCelebration(true);
    }
  }, [goalReached, dismissedForGoal, goal]);

  function addMoney() {
    const input = prompt("Сколько рублей добавить?");
    if (input === null || input.trim() === "") return;

    const amount = Number(input.replace(",", "."));
    if (!Number.isFinite(amount) || amount <= 0) {
      alert("Введите корректную сумму больше нуля.");
      return;
    }

    const now = new Date();
    setSaved((prev) => prev + amount);
    setHistory((prev) => [
      {
        id: `${now.getTime()}-${Math.random().toString(36).slice(2, 8)}`,
        amount,
        date: now.toLocaleDateString("ru-RU"),
        dateKey: getDateKey(now),
        time: now.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" }),
      },
      ...prev,
    ]);
  }

  function editGoal() {
    const name = prompt("Название цели:", goalName);
    if (name !== null && name.trim() !== "") setGoalName(name.trim());

    const input = prompt("Сумма цели:", goal);
    if (input === null || input.trim() === "") return;

    const amount = Number(input.replace(",", "."));
    if (Number.isFinite(amount) && amount >= 0) {
      setGoal(amount);
    } else {
      alert("Введите корректную сумму.");
    }
  }

  function handleStartNewGoal() {
    setShowCelebration(false);
    setDismissedForGoal(null);
    setSaved(0);
    setHistory([]);
    setGoalName("Новая мечта");
    setGoal(0);

    setTimeout(() => {
      const name = prompt("Как назовём новую мечту?", "Моя мечта");
      if (name !== null && name.trim() !== "") setGoalName(name.trim());

      const input = prompt("Сколько нужно накопить?");
      if (input === null || input.trim() === "") return;

      const amount = Number(input.replace(",", "."));
      if (Number.isFinite(amount) && amount > 0) {
        setGoal(amount);
      } else {
        alert("Введите корректную сумму больше нуля.");
      }
    }, 100);
  }

  function handleDismissCelebration() {
    setShowCelebration(false);
    setDismissedForGoal(goal);
  }

  return (
    <div className="savings-page">
      <header className="savings-header">
        <h1 className="logo">Фин<span>Тин</span></h1>
        <div className="savings-greeting">
          <p className="savings-greeting-top">🌿 Моя копилка</p>
          <h2>Каждый шаг — новый огонёк мечты</h2>
        </div>
      </header>

      {/* ===== КОСТЁР ===== */}
      <section className="fire-card">
        <div className="fire-stage">
          {/* поленница */}
          <div className="fire-logs">
            <span className="log log-1" />
            <span className="log log-2" />
            <span className="log log-3" />
          </div>

          {/* пламя — 3 слоя */}
          <div className="fire-flames">
            <span className={`flame flame-outer ${progress > 0 ? "visible" : ""}`} />
            <span className={`flame flame-mid ${progress >= 25 ? "visible" : ""}`} />
            <span className={`flame flame-inner ${progress >= 50 ? "visible" : ""}`} />
          </div>

          {/* искры — на 75%+ */}
          {progress >= 75 && (
            <div className="fire-sparks">
              {Array.from({ length: 8 }).map((_, i) => (
                <span key={i} className={`spark spark-${i}`} />
              ))}
            </div>
          )}

          {/* свечение — на 100% */}
          {goalReached && <div className="fire-glow" />}

          {/* угли */}
          <div className="fire-embers">
            <span className="ember ember-1" />
            <span className="ember ember-2" />
            <span className="ember ember-3" />
          </div>
        </div>

        <p className="fire-caption">
          {goalReached
            ? "🔥 Костёр горит ярко! Мечта сбылась!"
            : progress === 0
            ? "Подкинь дров — начни копить"
            : `🔥 Костёр разгорается: ${Math.round(progress)}%`}
        </p>
      </section>

      {/* ===== ЦЕЛЬ ===== */}
      <section className="goal-card">
        <p className="goal-label">Моя цель</p>
        <h2 className="goal-name">{goalName}</h2>
        <div className="goal-amount">{saved.toLocaleString("ru-RU")} ₽</div>
        <p className="goal-muted">из {goal.toLocaleString("ru-RU")} ₽</p>

        <div className="goal-progress">
          <div className="goal-progress-fill" style={{ width: `${progress}%` }} />
        </div>
        <p className="goal-percent">{Math.round(progress)}% накоплено</p>

        <button className="goal-add" onClick={addMoney}>
           Пополнить копилку
        </button>
        <button className="goal-edit" onClick={editGoal}>
           Изменить цель
        </button>
      </section>

      {/* ===== ОСТАЛОСЬ ===== */}
      <section className="remaining-card">
        {goalReached ? (
          <>
            <p className="remaining-label">Цель достигнута 🎉</p>
            <h2 className="remaining-value">Ты молодец!</h2>
          </>
        ) : (
          <>
            <p className="remaining-label">Осталось накопить</p>
            <h2 className="remaining-value">
              {Math.max(goal - saved, 0).toLocaleString("ru-RU")} ₽
            </h2>
          </>
        )}
      </section>

      {/* ===== ИСТОРИЯ ===== */}
      <section className="history-card">
        <h2 className="history-title">🍃 История операций</h2>
        {history.length === 0 ? (
          <p className="history-empty">Здесь пока нет операций. Пополни копилку!</p>
        ) : (
          history.map((item) => (
            <div className="history-item" key={item.id}>
              <div className="history-icon">💰</div>
              <div className="history-info">
                <strong>Пополнение копилки</strong>
                <p>{item.date} · {item.time}</p>
              </div>
              <strong className="history-amount">
                +{Number(item.amount).toLocaleString("ru-RU")} ₽
              </strong>
            </div>
          ))
        )}
      </section>

      {/* ===== ПРАЗДНИК ===== */}
      {showCelebration && (
        <div className="celebration-overlay" onClick={handleDismissCelebration}>
          <div className="celebration-modal" onClick={(e) => e.stopPropagation()}>
            <div className="celebration-emoji">🔥✨</div>
            <h2>Ты молодец!</h2>
            <p>
              Ты накопил {saved.toLocaleString("ru-RU")} ₽ на «{goalName}».
              Костёр мечты горит ярко! Хочешь зажечь новый?
            </p>
            <div className="celebration-actions">
              <button className="celebration-yes" onClick={handleStartNewGoal}>
                Да, новая мечта
              </button>
              <button className="celebration-no" onClick={handleDismissCelebration}>
                Пока нет
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===== НАВИГАЦИЯ ===== */}
      <nav className="bottom-nav">
        <button className="nav-item" onClick={() => onNavigate("home")}>
          <svg viewBox="0 0 24 24"><path d="M3 10.5L12 3l9 7.5V21h-6v-6H9v6H3z" /></svg>
          <span>Главная</span>
        </button>
        <button className="nav-item active">
          <svg viewBox="0 0 24 24"><rect x="3" y="6" width="18" height="14" rx="3" /><path d="M3 9h18" /><path d="M16 13h5" /><circle cx="16" cy="13" r="1" /><path d="M7 6V4h11v2" /></svg>
          <span>Копилка</span>
        </button>
        <button className="nav-item" onClick={() => onNavigate("courses")}>
          <svg viewBox="0 0 24 24" fill="none">
            <path d="M12 7.5C10.2 5.8 7.2 5 3.5 5.5V18 C7 17.5 10 18.3 12 20 C14 18.3 17 17.5 20.5 18V5.5 C16.8 5 13.8 5.8 12 7.5Z" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M12 7.5V20" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" />
            <path d="M6.5 9.5C8 9.5 9.3 9.8 10.2 10.4M6.5 12.5C8 12.5 9.3 12.8 10.2 13.4M17.5 9.5C16 9.5 14.7 9.8 13.8 10.4M17.5 12.5C16 12.5 14.7 12.8 13.8 13.4" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
          </svg>
          <span>Курсы</span>
        </button>
        <button className="nav-item" onClick={() => onNavigate("profile")}>
          <svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="4" /><path d="M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7z" /></svg>
          <span>Профиль</span>
        </button>
      </nav>
    </div>
  );
}